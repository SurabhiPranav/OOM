import javax.swing.*;
import java.awt.*;
import java.io.*;

public class FileViewer extends JFrame {
    private JTextArea fileContentArea;

    public FileViewer(String path) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("File Viewer");

        fileContentArea = new JTextArea();
        fileContentArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(fileContentArea);

        add(scrollPane, BorderLayout.CENTER);

        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        File file = new File(path);
        displayFile(file);
    }

    private void displayFile(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            fileContentArea.setText(content.toString());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading the file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FileViewer("path_to_your_file"));
    }
}
