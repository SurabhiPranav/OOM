public class Tag {
    // public static String[][] StringList = new String[100][100];
    // public static int[] no_tags = new int[100];

    public static String[] tags = new String[100];

    public Tag() {

    }

}
