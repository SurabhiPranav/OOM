import java.io.*;
import java.util.*;
import java.applet.*;
import java.awt.*;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

@SuppressWarnings("serial")

public class Add extends JPanel {

    JLabel t;
    JTextField t1;
     JLabel t2;
    JTextField t3;
     JLabel t4;
    JTextField t5;
     JLabel t6;
    JTextField t7;
    String path;
    public Add() {

        Document d = new Document("Roys", 28);
        Topic top = new Topic();
        Category c = new Category();
        Tag g = new Tag();

        setLayout(new GridLayout(5, 2));

        t = new JLabel("ENTER DOCUMENT NAME");
        t.setSize(300, 300);
        

        t1 = new JTextField();
        t1.setSize(300, 300);
        t1.setEditable(true);

        

        t2 = new  JLabel("ENTER TOPIC");
        t2.setSize(300, 300);
        

        t3 = new JTextField();
        t3.setSize(300, 300);
        t3.setEditable(true);

       
        t4 = new  JLabel("ENTER CATEGORY");
        t4.setSize(300, 300);
       

        t5 = new JTextField();
        t5.setSize(300, 300);
        t5.setEditable(true);

        
        t6 = new  JLabel("ENTER TAGS (IF ANY ELSE TYPE NIL)");
        t6.setSize(300, 300);
       

        t7 = new JTextField();
        t7.setSize(300, 300);
        t7.setEditable(true);
        JButton A=new JButton("ADD File");
        JButton j = new JButton("PROCEED");

       // Assuming d, top, c, and g are defined or instantiated somewhere in your code

// Add ActionListener to the button 'j'
j.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Get text from JTextField t1 and store it in d.doc_name
        String documentName = t1.getText();
        d.doc_name[d.counter] = documentName;
       d.content[d.counter] =path;
        // Get text from JTextField t3 and store it in top.topic
        String topicText = t3.getText();
        top.topic[d.counter] = topicText;

        // Get text from JTextField t5 and store it in c.category
        String categoryText = t5.getText();
        c.category[d.counter] = categoryText;

        // Ensure d.counter - 1 is within the bounds of g.tags array before assigning the text
        
            // Get text from JTextField t7 and store it in g.tags
            String tagsText = t7.getText();
            g.tags[d.counter] = tagsText;
       

        // Increment the counter
        d.counter++;

        // Create and configure a new JFrame
        JFrame jFrame = new JFrame();
        jFrame.setTitle("CHOOSING PAGE");

        Add a = new Add();
        Container cPane = jFrame.getContentPane();
        Newclass template = new Newclass(a, cPane);
        jFrame.setSize(template.getSize());
        jFrame.setResizable(false);
        cPane.add(template);

        jFrame.setVisible(true);
        jFrame.setLocationRelativeTo(null);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }
});
A.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();

        // Set file selection mode to files only (not directories)
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int result = fileChooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();

            // Store the absolute path of the selected file in the content array of Document d
           path = selectedFile.getAbsolutePath();
            System.out.println(path);

            // Increment the counter
           

            // You can perform additional actions with the selected file or its path here
        } else if (result == JFileChooser.CANCEL_OPTION) {
            System.out.println("File selection canceled.");
        }
    }
});

         //JLabel empty=new JLabel();

         this.add(t);
         this.add(t1);
         this.add(t2);
         this.add(t3);
         this.add(t4);
         this.add(t5);
         this.add(t6);
         this.add(t7);
         this.add(A);
         this.add(j);

     }

}
