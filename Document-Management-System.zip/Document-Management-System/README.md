# Document-Management-System
A JAVA SWING based document management system
