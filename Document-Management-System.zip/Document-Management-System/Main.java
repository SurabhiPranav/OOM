import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
public class Main extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private HashMap<String, String > Hash = new HashMap<>();
    public Main() {
        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = String.valueOf(passwordField.getPassword());

                if (isValidLogin(username, password)) {
                    JOptionPane.showMessageDialog(null, "Welcome " + username);
                    // Replace the JOptionPane with your logic to open the new frame
                    openNewFrame();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password");
                }
            }
        });

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = String.valueOf(passwordField.getPassword());
                Hash.put(username,password);
                JOptionPane.showMessageDialog(null, "Registered new user: " + username);
            }
        });

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // Empty space for layout
        panel.add(loginButton);
        panel.add(new JLabel()); // Empty space for layout
        panel.add(registerButton);

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }
    private boolean isValidLogin(String username, String password) {
        // Assuming Hash is a HashMap<String, String> containing username-password pairs
        for (String key : Hash.keySet()) {
            String value = Hash.get(key);
            // Use equals() for string comparison, not ==
            if (username.equals(key) && password.equals(value)) {
                return true;
            }
        }
        return false;
    }
    

    private void openNewFrame() {
        JFrame jFrame = new JFrame();
        jFrame.setTitle("CHOOSING PAGE");

        // Assuming the logic to open a new frame is in the 'Newclass' class
        Add a = new Add();
        Container cPane = jFrame.getContentPane();
        Newclass template = new Newclass(a, cPane);
        jFrame.setSize(template.getSize());
        jFrame.setResizable(false);
        cPane.add(template);

        jFrame.setVisible(true);
        jFrame.setLocationRelativeTo(null);
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main login = new Main();
            login.setVisible(true);
        });
    }
}
