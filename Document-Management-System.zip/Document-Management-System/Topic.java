public class Topic {
    
    public static String[] topic= new String[100];
    public Topic()
    {
        
    }
}
