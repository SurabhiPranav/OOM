public class Category {
    
    public static String[] category= new String[100];
    public Category()
    {

    }
}
