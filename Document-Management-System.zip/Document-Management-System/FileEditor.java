import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FileEditor extends JFrame {
    private JTextArea fileContentArea;
    private File file;

    public FileEditor(String path) {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("File Editor");

        fileContentArea = new JTextArea();
        fileContentArea.setEditable(true);

        JScrollPane scrollPane = new JScrollPane(fileContentArea);

        add(scrollPane, BorderLayout.CENTER);

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new SaveListener());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(saveButton);

        add(buttonPanel, BorderLayout.SOUTH);

        setSize(600, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        file = new File(path);
        displayFile(file);
    }

    private void displayFile(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            fileContentArea.setText(content.toString());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading the file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private class SaveListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            saveFile();
        }
    }

    private void saveFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(fileContentArea.getText());
            JOptionPane.showMessageDialog(this, "File saved successfully!", "Save Successful", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving the file: " + ex.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FileEditor("path_to_your_file"));
    }
}
